# Python modules
#----------------
import requests             # Requêtes HTTP - A installer
import json                 # Lire format JSON
import dataextract as tde   # Tableau data extract api - A installer
import os

# Créer un extrait de données Tableau vide (supprimer l'ancien si besoin)
# Modifier la prochaine ligne pour indiquer le dossier/fichier TDE à créer
#    ex: extract_file = 'C:\dossier_de_test\velib.tde'
#-------------------------------------------------------------------
extract_file = 'velib.tde' 

if os.path.isfile(extract_file):
    os.remove(extract_file)
tdefile = tde.Extract(extract_file)

# Décrire la structure de l'extrait
# Chaque colonne se voit attribuer un nom (visible dans Tableau) et un type de données
#---------------------------------------------------------------------------------------------------
tableDef = tde.TableDefinition()
tableDef.addColumn('number', tde.Type.INTEGER)
tableDef.addColumn('address', tde.Type.CHAR_STRING)
tableDef.addColumn('latitude', tde.Type.DOUBLE)
tableDef.addColumn('longitude', tde.Type.DOUBLE)
tableDef.addColumn('bike_stands', tde.Type.INTEGER)
tableDef.addColumn('available_bike_stands', tde.Type.INTEGER)
tableDef.addColumn('available_bikes', tde.Type.INTEGER)
table = tdefile.addTable('Extract', tableDef)

newrow = tde.Row(tableDef)

  
# Lire les données JSON et les écrire dans l'extrait Tableau
# IMPORTANT : insérer votre clé API en ligne 40 ci-dessous
# Cette URL filtre les données pour Paris mais peut être utilisée pour d'autres villes (Marseille, Bruxelles, Dublin...)
#-----------------------------------------------------------------------------------------------------------------------

# Exécuter la requête HTTP
stations = requests.get('https://api.jcdecaux.com/vls/v1/stations?apiKey=VOTRE-CLE-API&contract=Paris').json()

# Boucle de lecture des données retournées par la requête
# Charger les données issues de la requête dans l'extrait de données Tableau
for station in stations:
    if station['status'] == 'OPEN':
        newrow.setInteger(0, station['number'])
        newrow.setCharString(1, station['address'])
        newrow.setDouble(2, station['position']['lat'])		# Note the 2 level naming convention position -> lat
        newrow.setDouble(3, station['position']['lng'])
        newrow.setInteger(4, station['bike_stands'])
        newrow.setInteger(5, station['available_bike_stands'])
        newrow.setInteger(6, station['available_bikes'])
        table.insert(newrow)

# Fermer l'extrait
#-------------------
tdefile.close()
