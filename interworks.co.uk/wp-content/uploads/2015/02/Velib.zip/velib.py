# Python modules
#----------------
import requests             # HTTP requests - To be installed
import json                 # Read JSON format
import dataextract as tde   # Tableau data extract api - To be installed
import os

# Create an empty Tableau Extract (delete existing one if any)
# Modify next line to include a directory for the extract if needed 
#    ie: extract_file = 'C:\test_directory\velib.tde'
#-------------------------------------------------------------------
extract_file = 'velib.tde' 

if os.path.isfile(extract_file):
    os.remove(extract_file)
tdefile = tde.Extract(extract_file)

# Describe the Extract structure
# Each column is given a name (visible in Tableau) and a data type
# Later in the code, destination columns will be referred to by their number, starting with 0
#---------------------------------------------------------------------------------------------
tableDef = tde.TableDefinition()
tableDef.addColumn('number', tde.Type.INTEGER)
tableDef.addColumn('address', tde.Type.CHAR_STRING)
tableDef.addColumn('latitude', tde.Type.DOUBLE)
tableDef.addColumn('longitude', tde.Type.DOUBLE)
tableDef.addColumn('bike_stands', tde.Type.INTEGER)
tableDef.addColumn('available_bike_stands', tde.Type.INTEGER)
tableDef.addColumn('available_bikes', tde.Type.INTEGER)
table = tdefile.addTable('Extract', tableDef)

newrow = tde.Row(tableDef)
    
# Read JSON data and write into the Tableau Extract
# IMPORTANT : insert your API key where indicated
# The URL filters data for Paris only but can be used for other cities (Marseille, Bruxelles, Dublin...)
#--------------------------------------------------------------------------------------------------------

# Launch the HTTP request
stations = requests.get('https://api.jcdecaux.com/vls/v1/stations?apiKey=YOUR-API-KEY-HERE&contract=Paris').json()

# Loop through the data returned by the request
# Load the extract columns with specified data from the JSON structure returned by the request
for station in stations:
    if station['status'] == 'OPEN':
        newrow.setInteger(0, station['number'])
        newrow.setCharString(1, station['address'])
        newrow.setDouble(2, station['position']['lat'])		# Note the 2 level naming convention position -> lat
        newrow.setDouble(3, station['position']['lng'])
        newrow.setInteger(4, station['bike_stands'])
        newrow.setInteger(5, station['available_bike_stands'])
        newrow.setInteger(6, station['available_bikes'])
        table.insert(newrow)

# Close the extract
#-------------------
tdefile.close()
